from aiogram import types
from aiogram.dispatcher.filters import BoundFilter



class GroupPrivate(BoundFilter):
        async def check(self, message: types.Message) -> bool:
            return message.chat.type in (
                types.ChatType.GROUP,
            )

class GroupSuper(BoundFilter):
        async def check(self, message: types.Message) -> bool:
            return message.chat.type in (
                types.ChatType.SUPERGROUP,
            )

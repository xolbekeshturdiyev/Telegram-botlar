from loader import dp
from .admins import AdminFilter
from filters.groupfilter import IsGroup
from .group_chat import GroupPrivate,GroupSuper
from .private_chat import IsPrivate


if __name__ == "filters":
    dp.filters_factory.bind(AdminFilter)
    dp.filters_factory.bind(GroupPrivate)
    dp.filters_factory.bind(IsGroup)
    dp.filters_factory.bind(GroupSuper)
    dp.filters_factory.bind(IsPrivate)

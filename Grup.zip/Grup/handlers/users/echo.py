from aiogram import types
from filters import IsPrivate,IsGroup,AdminFilter

from loader import dp
command=['/stop','/unstop','/kick','/unkick','/set_photo','/set_title','/set_description']
for c in command:
    @dp.message_handler(IsPrivate(), text=c)
    async def bot_echo(message: types.Message):
        await message.answer('Bu buyruqlar faqat guruhlarda ishlaydi.')
        

# Echo bot
@dp.message_handler(IsPrivate(), state=None)
async def bot_echo(message: types.Message):
    await message.answer('Xabaringiz tushunarsiz ketdi.')

from aiogram import types
from aiogram.types import Message
from keyboards.default.qoida import menustart
from loader import dp

@dp.message_handler(text="🗒 Botdan foydalanish qo`llanmasi")
async def select_category(message: Message):
    await message.answer(f"Botdan foydalanish uchun botni guruhingizga admin qiling va komandalar yordamida guruhingizda tartib o`rnatishingiz mumkin.\n"
                         f"Botdagi komandalarni /help orqali ko`rib oling.")
    await message.answer("Botdagi komandalar ishlash uslubi.\n"
                         "/set_photo - Guruhga rasm yuboring va unga javob sifatida(reply) shu komandani yuborsangiz guruh rasmi o`zgaradi.\n"
                         "/set_title - Guruhga matn yuboring va unga javob sifatida(reply) shu komandani yuborsangiz guruh nomi o`zgaradi.\n"
                         "/set_description - Guruhga matn yuboring va unga javob sifatida(reply) shu komandani yuborsangiz guruh ma`lumotlari o`zgaradi.\n"
                         "/stop - Guruh a`zosi yuborgan matnga javob sifatida(reply) shu komanda bilan raqam yuborsangiz\n (masalan: /stop 15)"
                         "ushbu foydalanuvhi shuncha minutga xabar yoza olmaydi.\nAgar siz komanda bilan so`z yuborsangiz\n (masalan: /stop Reklama)"
                         "ushbu foydalanuvhi ushbu sabab tufayli 5minut xabar yoza olmaydi.\n(masalan: /stop 30 rasm - ushbu foydalanuvchi rasm yuborganligi"
                         "uchun 30minut xabar yoza olamydi)\n"
                         "/unstop - Guruh a`zosi yuborgan matnga javob sifatida(reply) shu komandani yuborsangiz /stop komandasini o`chiradi.\n"
                         "/kick - Guruh a`zosi yuborgan matnga javob sifatida(reply) shu komandani yuborsangiz ushbu guruh a`zosi guruhdan haydaladi.\n"
                         "Agar sizning guruhingiz superguruh bo`lsa ushbu guruh a`zosi -Qora Ro`yxat- ga tushadi va uning o`zi ushbu guruhga qaytib qo`shila olmaydi.\n"
                         "Guruhingiz oddiy guruh bo`lsa foydalanuvhi shunchaki chiqarlib yuboriladi.\n"
                         "/unkick - Guruh a`zosi yuborgan matnga javob sifatida(reply) shu komandani yuborsangiz ushbu guruh a`zosi (faqat superguruhda) -Qora Ro`yxat-"
                         "dan o`chiriladi va uning o`zi guruh linki yordamida guruhga qaytib qo`shilishi mumkin.")

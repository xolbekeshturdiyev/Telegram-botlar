import asyncio

from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandHelp
from filters import IsPrivate,IsGroup
from loader import dp


@dp.message_handler(IsPrivate(),CommandHelp())
async def bot_help(message: types.Message):
    text = ("/start", "Botni ishga tushurish\n",
            "/help", "Yordam\n",
            "/set_photo", "Guruh rasmini o'zgartirish\n",
            "/set_title", "Guruh nomini o'zgartirish\n",
            "/set_description", "Guruh haqidagi ma'lumotni o'zgatirish\n",
            "/stop", "Foydalanuvchini Read Only (RO) rejimga o'tkazish\n",
            "/unstop", "RO rejimdan chiqarish\n",
            "/kick", "Ban\n",
            "/unkick", "Bandan chiqarish\n",)
    
    await message.answer("\n".join(text))

@dp.message_handler(IsGroup(),CommandHelp())
async def bot_help(message: types.Message):
    matn=await message.reply('Barcha yordamlar uchun shaxsiy aloqaga o`ting')
    await asyncio.sleep(5)
    await message.delete()
    await matn.delete()

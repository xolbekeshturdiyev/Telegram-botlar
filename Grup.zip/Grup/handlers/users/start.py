from aiogram import types
from aiogram.types import Message
from aiogram.dispatcher.filters.builtin import CommandStart
from keyboards.default.qoida import menustart
from filters import GroupPrivate,GroupSuper,IsPrivate,IsGroup
from loader import dp
import asyncio



@dp.message_handler(IsPrivate(),CommandStart())
async def bot_start(message: types.Message):
    await message.answer(f"Salom, {message.from_user.full_name}!",reply_markup=menustart)



@dp.message_handler(IsGroup(),CommandStart())
async def botstart(message:types.Message):
	await message.answer(f"Salom, {message.from_user.full_name} siz guruhdasiz!")


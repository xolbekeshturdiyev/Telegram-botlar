import asyncio
import datetime
import re
from aiogram.types.chat_member import ChatMemberAdministrator,ChatMemberOwner
from aiogram.types import base, fields
import aiogram
from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.utils.exceptions import BadRequest

from filters import GroupSuper,AdminFilter,IsGroup
from loader import dp, bot


# /ro oki !ro (read-only) komandalari uchun handler
# foydalanuvchini read-only ya'ni faqat o'qish rejimiga o'tkazib qo'yamiz.
@dp.message_handler(GroupSuper(), Command("stop", prefixes="!/"), AdminFilter())
async def read_only_mode(message: types.Message):
    try:
        member = message.reply_to_message.from_user
        member_id = member.id
        chat_id = message.chat.id
        command_parse = re.compile(r"(!stop|/stop) ?(\d+)? ?([\w+\D]+)?")
        parsed = command_parse.match(message.text)
        time = parsed.group(2)
        comment = parsed.group(3)
        if not time:
            time = 5

        time = int(time)

        # Ban vaqtini hisoblaymiz (hozirgi vaqt + n minut)
        until_date = datetime.datetime.now() + datetime.timedelta(minutes=time)


        await message.chat.restrict(user_id=member_id, can_send_messages=False, until_date=until_date)
        await message.reply_to_message.delete()


        # Пишем в чат
        await message.answer(f"Foydalanuvchi {message.reply_to_message.from_user.full_name} {time} minut yozish huquqidan mahrum qilindi.\n"
                             f"Sabab: \n<b>{comment}</b>")

        await asyncio.sleep(5)
        await message.delete()
    except AttributeError:
        matn = await message.reply('ILtimos foydalanuvchiga javob orqali yozing.')
        await asyncio.sleep(5)
        await message.delete()
        await matn.delete()

# read-only holatdan qayta tiklaymiz
@dp.message_handler(GroupSuper(), Command("unstop", prefixes="!/"), AdminFilter())
async def undo_read_only_mode(message: types.Message):
    try:
        member = message.reply_to_message.from_user
        member_id = member.id
        chat_id = message.chat.id

        user_allowed = types.ChatPermissions(
            can_send_messages=True,
            can_send_media_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_invite_users=True,
            can_change_info=False,
            can_pin_messages=False,
        )


        await asyncio.sleep(5)
        await message.chat.restrict(user_id=member_id, permissions=user_allowed, until_date=0)
        await message.reply(f"Foydalanuvchi {member.full_name} o`qish rejimidan chiqarildi.")

        # xabarlarni o'chiramiz
        await message.delete()
    except AttributeError:
        matn = await message.reply('ILtimos foydalanuvchiga javob orqali yozing.')
        await asyncio.sleep(5)
        await message.delete()
        await matn.delete()

# Foydalanuvchini banga yuborish (guruhdan haydash)
@dp.message_handler(GroupSuper(), Command("kick", prefixes="!/"), AdminFilter())
async def ban_user(message: types.Message):
    try:
        member = message.reply_to_message.from_user
        member_id = member.id
        chat_id = message.chat.id
        await message.chat.kick(user_id=member_id)

        await message.answer(f"{message.left_chat_member.full_name} guruhdan haydaldi\n"
                             f"Admin: {message.from_user.get_mention(as_html=True)}.")

        await asyncio.sleep(5)
        await message.delete()
    except AttributeError:
        matn = await message.reply('ILtimos foydalanuvchiga javob orqali yozing.')
        await asyncio.sleep(5)
        await message.delete()
        await matn.delete()

# Foydalanuvchini bandan chiqarish, foydalanuvchini guruhga qo'sha olmaymiz (o'zi qo'shilishi mumkin)
@dp.message_handler(GroupSuper(), Command("unkick", prefixes="!/"), AdminFilter())
async def unban_user(message: types.Message):
    try:
        member = message.reply_to_message.from_user
        member_id = member.id
        chat_id = message.chat.id
        await message.chat.unban(user_id=member_id)
        await message.answer(f"Foydalanuvchi {message.reply_to_message.from_user.full_name} blokdan chiqarildi. Uning o`zi qaytib qo`shilsa bo`ladi."
                             f"Admin: {message.from_user.get_mention(as_html=True)}.")

        await asyncio.sleep(5)

        await message.delete()
    except AttributeError:
        matn = await message.reply('ILtimos foydalanuvchiga javob orqali yozing.')
        await asyncio.sleep(5)
        await message.delete()
        await matn.delete()



@dp.message_handler(IsGroup(), Command("kickme", prefixes="!/"))
async def ban_user(message: types.Message):
        member = message.from_user
        member_id = member.id
        await message.chat.kick(user_id=member_id)
        await message.chat.unban(user_id=member_id)
        await message.answer(f"{message.left_chat_member.full_name} guruhdan chiqdi>\nSabab: Hazil")
        await asyncio.sleep(5)
        await message.delete()
  
    	

@dp.message_handler(IsGroup(), Command("pin", prefixes="!/"), AdminFilter())
async def pinned(message: types.Message):
    msg=message.reply_to_message
    await msg.pin()
    await message.delete()
    
  
@dp.message_handler(IsGroup(), Command("unpin", prefixes="!/"), AdminFilter())
async def unpin(message:types.Message):
        msg=message.reply_to_message
        await msg.unpin()
        await message.delete()


@dp.message_handler(IsGroup(), Command("count", prefixes="!/"), AdminFilter())
async def get_administrators(message:types.Message):
        a=await bot.get_chat_administrators(message.chat.id)
        print(a)
from aiogram import types

async def set_default_commands(dp):
    await dp.bot.set_my_commands(
        [
            types.BotCommand("start", "Botni ishga tushurish"),
            types.BotCommand("help", "Yordam"),
            types.BotCommand("stop", "Foydalanuvchini o`qish rejimga o'tkazish"),
            types.BotCommand("kick", "Chiqarib yuborish va bloklash"),
            types.BotCommand("unkick", "Blokdan chiqarish"),
            types.BotCommand("unstop", "O`qish rejimdan chiqarish"),
            types.BotCommand("set_photo", "Guruh rasmini o'zgartirish"),
            types.BotCommand("set_title", "Guruh nomini o'zgartirish "),
            types.BotCommand("set_description", "Guruh haqidagi ma'lumotni o'zgatirish"),
        ]
    )

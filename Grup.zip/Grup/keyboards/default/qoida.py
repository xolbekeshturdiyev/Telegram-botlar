from aiogram.types import ReplyKeyboardMarkup,KeyboardButton
menustart=ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text='🗒 Botdan foydalanish qo`llanmasi'),
        ],
    ],
    resize_keyboard=True
)